# coding=utf-8

from colorama import *
from random import choice
import os
os.system('clear' and 'cls')
init()

logo = Fore.BLUE+"""

░██████╗███╗░░██╗██╗██████╗░███████╗██████╗░
██╔════╝████╗░██║██║██╔══██╗██╔════╝██╔══██╗
╚█████╗░██╔██╗██║██║██████╔╝█████╗░░██████╔╝
░╚═══██╗██║╚████║██║██╔═══╝░██╔══╝░░██╔══██╗
██████╔╝██║░╚███║██║██║░░░░░███████╗██║░░██║
╚═════╝░╚═╝░░╚══╝╚═╝╚═╝░░░░░╚══════╝╚═╝░░╚═╝ """



def print_logo():
    print(Fore.RED + Style.BRIGHT + logo + Style.RESET_ALL + Style.BRIGHT +"\n")
    print(Fore.RED + "TheDbSearcher Project: https://T.me/snipper_black"+ Style.RESET_ALL + Style.BRIGHT)
    print(Style.RESET_ALL + Style.BRIGHT, Style.BRIGHT)
